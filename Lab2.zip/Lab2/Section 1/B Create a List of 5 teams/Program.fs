﻿type Coach = {
    Name : string
    former_player : bool
}

type Stats = {
    Wins : int
    Losses : int
}

type Team = {
    Name : string
    Coach : Coach
    Stats : Stats
}

let coaches = 
    Map.ofList [
        ("San Antonio Spurs", { Name = "Gregg Popovich"; former_player = true })
        ("Boston Celtics", { Name = "Joe Mazzulla"; former_player = false })
        ("Los Angeles Lakers", { Name = "Darvin Ham"; former_player = false })
        ("Utah Jazz", { Name = "Quin Snyder"; former_player = false })
        ("Phoenix Suns", { Name = "Igor Kokoskov"; former_player = false })
    ]

let stats = 
    Map.ofList [
        ("San Antonio Spurs", { Wins = 2283; Losses = 1502 })
        ("Boston Celtics", { Wins = 3570; Losses = 2462 })
        ("Los Angeles Lakers", { Wins = 3503; Losses = 2419 })
        ("Utah Jazz", { Wins = 2146; Losses = 1804 })
        ("Phoenix Suns", { Wins = 2380; Losses = 2063 })
    ]

let teams = 
    [
        { Name = "San Antonio Spurs"; Coach = coaches["San Antonio Spurs"]; Stats = stats["San Antonio Spurs"] }
        { Name = "Boston Celtics"; Coach = coaches["Boston Celtics"]; Stats = stats["Boston Celtics"] }
        { Name = "Los Angeles Lakers"; Coach = coaches["Los Angeles Lakers"]; Stats = stats["Los Angeles Lakers"] }
        { Name = "Utah Jazz"; Coach = coaches["Utah Jazz"]; Stats = stats["Utah Jazz"] }
        { Name = "Phoenix Suns"; Coach = coaches["Phoenix Suns"]; Stats = stats["Phoenix Suns"] }
    ]

for team in teams do
    printfn "Team: %s, Coach: %s, Former Player: %b, Wins: %d, Losses: %d" 
        team.Name team.Coach.Name team.Coach.former_player team.Stats.Wins team.Stats.Losses
