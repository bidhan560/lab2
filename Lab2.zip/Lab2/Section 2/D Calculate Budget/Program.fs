﻿type Cuisine =
    | Korean
    | Turkish

type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float

let rec calculate_movie_price movieType =
    match movieType with
    | Regular -> 12.0
    | IMAX -> 17.0
    | DBOX -> 20.0
    | RegularWithSnacks -> calculate_movie_price Regular + 5.0
    | IMAXWithSnacks -> calculate_movie_price IMAX + 5.0
    | DBOXWithSnacks -> calculate_movie_price DBOX + 5.0

let calculate_budget activity =
    match activity with
    | BoardGame | Chill -> 0.0
    | Movie movieType -> calculate_movie_price movieType
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0
        | Turkish -> 65.0
    | LongDrive (kilometers, fuelPerKm) -> float kilometers * fuelPerKm

let activity = Movie IMAXWithSnacks
let budget = calculate_budget activity
printfn "The budget for the IMAX with Snacks is: %f CAD" budget
