﻿type Cuisine =
    | Korean
    | Turkish

